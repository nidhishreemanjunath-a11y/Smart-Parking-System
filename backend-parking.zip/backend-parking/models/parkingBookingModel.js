const mongoose = require("mongoose");

const parkingBookingSchema = new mongoose.Schema({
  slotId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "ParkingSlot",
    required: true
  },

  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

  // ✅ SAFE ADDITION
  hours: {
    type: Number,
    default: 1
  }

}, { timestamps: true });

module.exports = mongoose.model("ParkingBooking", parkingBookingSchema);