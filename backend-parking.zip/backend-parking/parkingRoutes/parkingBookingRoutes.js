const express = require("express");
const router = express.Router();


const { createBooking, getBookings, deleteBooking } = require("../controllers/parkingBookingController");

router.post("/create-booking", createBooking);
router.get("/get-bookings", getBookings);
router.delete("/delete-booking/:id", deleteBooking);
router.delete("/cancel-by-slot/:slotId", cancelBySlot);

module.exports = router;