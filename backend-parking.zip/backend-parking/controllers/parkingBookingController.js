const Booking = require("../models/parkingBookingModel");
const ParkingSlot = require("../parkingModels/parkingSlotModel"); 

// CREATE BOOKING
const createBooking = async (req, res) => {
  try {
    console.log("REQ BODY:", req.body);

    const { slotId, userId, hours } = req.body;

    if (!slotId || !userId || !hours) {
      return res.status(400).json({ message: "Missing data" });
    }

 const slotData = await ParkingSlot.findById(slotId);

    if (!slotData) {
      return res.status(404).json({ message: "Slot not found" });
    }

    if (slotData.isBooked) {
      return res.status(400).json({ message: "Already booked" });
    }

   const booking = new Booking({
  slotId,
  userId,
  hours
});

    slotData.isBooked = true;
    slotData.hours = Number(hours);
    await slotData.save();

    res.status(200).json({ message: "Booking success", booking });

  } catch (error) {
    console.error("ERROR:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// GET BOOKINGS
const getBookings = async (req, res) => {
  try {
    const bookings = await Booking.find().populate("slotId");
    res.json(bookings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// DELETE BOOKING
const deleteBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);

    if (!booking) {
      return res.status(404).json({ message: "Not found" });
    }

   await ParkingSlot.findByIdAndUpdate(slotId, {
  isBooked: true,
  hours
});

    await Booking.findByIdAndDelete(req.params.id);

    res.json({ message: "Cancelled" });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createBooking,
  getBookings,
  deleteBooking,
};